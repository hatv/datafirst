/*eslint-env node*/

// This code run on the server side under Node/Express.

//------------------------------------------------------------------------------
// node.js starter application for Bluemix
//------------------------------------------------------------------------------


// This application uses express as its web server
// for more info, see: http://expressjs.com
var express = require('express');

// cfenv provides access to your Cloud Foundry environment
// for more info, see: https://www.npmjs.com/package/cfenv
var cfenv = require('cfenv');

// create a new express server
var app = express();

// Load the Cloudant library.
var Cloudant = require('cloudant');

// create a new HTTP request handler
var request = require('request');

// Process the VCAP_SERVICES environment variables for the
// bound Cloudant service.
var vcap_services = process.env.VCAP_SERVICES;
var cloudant_services = JSON.parse(vcap_services)["cloudantNoSQLDB"][0];


// Use the VCAP variables to authenticate with Cloudant.
var cloudant = Cloudant({
	account : cloudant_services.credentials.username,
	password : cloudant_services.credentials.password
});

// var greatwest = cloudant.db.use('greatwestsports');
var greatwest = cloudant.db.use('greatoutdoors');

// serve the files out of ./public as our main files
app.use(express.static(__dirname + '/public'));

// get the app environment from Cloud Foundry
var appEnv = cfenv.getAppEnv();

// This construct allows the same code to be run locally or in the cloud
var port = (process.env.VCAP_APP_PORT || 3000);
var host = (process.env.VCAP_APP_HOST || 'localhost');

// start server on the specified port and binding host
app.listen(appEnv.port, '0.0.0.0', function() {

	// print a message when the server starts listening
	console.log("server starting on " + appEnv.url);
});

// Create routes for the web page to call into

// Route to get all the shoppers
app.get('/get_shoppers', function(req, res) {

    var cloudantURL = appEnv.services['cloudantNoSQLDB'][0].credentials.url;
    var requestURL = cloudantURL + "/greatoutdoors/_design/viewByTimestamp/_view/viewByTimestamp";
    
    // Run query to find latest evictTS in database
	request(requestURL, function (error, response, body) {
	  if (!error && response.statusCode === 200) {
	    res.send(body);
	  }
	});
});

// Route to get all the shoppers that were in the store in the past 30s
app.get('/get_shoppers_30s', function(req, res) {

    var cloudantURL = appEnv.services['cloudantNoSQLDB'][0].credentials.url;
    var requestBaseURL = cloudantURL + "/greatoutdoors/_design/viewByTimestamp/_view/viewByTimestamp";
    
    // Get the current time and offset it to October the 18th for demo purpose
    var now = new Date();
    var eighteenth = new Date('2016-10-18');
    var date = eighteenth.getTime() + now.getHours()*3600000 + now.getMinutes() * 60000 + now.getSeconds()* 1000 + now.getMilliseconds();
    
    // Get the time it was 5 minutes ago (still with the offset)
    var thirtySecAgo = date - 30000;
    
    // Find every shopper that was in the shop between these two dates using the view defined in Cloudant
    var requestURL = requestBaseURL + '?startkey=' + thirtySecAgo + '&endkey=' + date;
    request(requestURL, function (error, response, body) {
	  if (!error && response.statusCode === 200) {
	    res.send(body);
	  }
	});
});
