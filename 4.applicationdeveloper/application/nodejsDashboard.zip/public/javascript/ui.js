/**
 * This is where the code goes for the UI
 */

$(document).ready(
		function() {

			// Populate the Cloudant database if it is empty
			//populateDatabase();
			
			var IDToIndex = {"Camping Equipment":0, "Golf Equipment":1, "Mountaineering Equipment":2, "Outdoor Protection":3, "Personal Accessories":4};
			
			// create an array zones to contain the number of shoppers
			// in each zone and initialize it with dummy values
			// These values will change afterward
			zonesDay = [ 4.3, 3.9, 4.5, 6, 3.2 ];
			zonesLast30s = [ 3.3, 3.8, 4.0, 6, 3.9 ];
			
			// Create store list dropdown using jQuery
			// This data will be generated programmatically in the future
			var storedata = {
				'GO-CO-001' : 'GO-CO-001',
				'GO-CO-002' : 'GO-CO-002',
				'GO-CO-003' : 'GO-CO-003',
				'GO-CO-004' : 'GO-CO-004'
			};

			var s = $('<select name="stores" id="stores"/>');

			for ( var val in storedata) {
				$('<option />', {
					value : val,
					text : storedata[val]
				}).appendTo(s);
			}

			// Append the dropdown to the HTML form
			s.appendTo('#gui1_form');

			// Initialize the bar chart
			 $('#chartContainer').highcharts({
			        chart: {
			            type: 'column'
			        },
			        title: {
			            text: 'Average number of shoppers per zone of the store'
			        },
			        credits:false,
			        xAxis: {
			            categories: [
			                'Camping Equipment',
			                'Golf Equipment',
			                'Mountaineering Equipment',
			                'Outdoor Protection',
			                'Personal Accessories'
			            ],
			            crosshair: true
			        },
			        yAxis: {
			            min: 0,
			            max: 9,
			            title: {
			                text: 'Number of shoppers'
			            }
			        },
			        tooltip: {
			            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
			            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
			                '<td style="padding:0"><b>{point.y:.1f}</b></td></tr>',
			            footerFormat: '</table>',
			            shared: true,
			            useHTML: true
			        },
			        plotOptions: {
			            column: {
			                pointPadding: 0.2,
			                borderWidth: 0
			            }
			        },
			        series: [{
			            name: 'Average number of shoppers throughout the day',
			            data: zonesDay
			
			        }, {
			            name: 'Average number of shoppers in the last 30 seconds',
			            data: zonesLast30s
			
			        }]
			    });



			// REST endpoint to query Cloudant for Shoppers in each zone. Not optimized and therefore quite ressource intensive, see below for more information.
			function updateDayData() {
								
				$.getJSON("/get_shoppers", function(data) {

					var dataArray = data.rows;
					
					// clear previous zone data to prevent incrementation of values
					zonesDay = [ 0, 0, 0, 0, 0 ];
					
					// Get the shopper data JSON and convert it to an array of
					// zones containing the number of shoppers in each zone.
					for (var i = 0; i < dataArray.length; i++) {
						//Only take into account the data for the currently selected store
						var selectedStore = $("#stores option:selected").text();
						if (selectedStore === dataArray[i].value.storeID) {
							// increment the number of shoppers in the zone
							zonesDay[IDToIndex[dataArray[i].value.zoneID]] += dataArray[i].value.count;
						}
					}
					
					var chart = $('#chartContainer').highcharts()
									
					for (var i = 0; i < zonesDay.length; i++) {
						// Compute the average number of shoppers per minute
						zonesDay[i] = zonesDay[i]/(24 * 60);
						chart.series[0].data[i].update(zonesDay[i]); 
					}
					
				});

			};  // end shopperData()
			
			// REST endpoint to query Cloudant for Shoppers present in the different zones for the last 30s.
			// This will be called every few seconds
			function update30sData() {
								
				$.getJSON("/get_shoppers_30s", function(data) {

					var dataArray = data.rows;
					
					// clear previous zone data to prevent incrementation of values
					zonesLast30s = [ 0, 0, 0, 0, 0 ];
					
					// Get the shopper data JSON and convert it to an array of
					// zones containing the number of shoppers in each zone.
					for (var i = 0; i < dataArray.length; i++) {
						//Only take into account the data for the currently selected store
						var selectedStore = $("#stores option:selected").text();
						if (selectedStore === dataArray[i].value.storeID) {
							// increment the number of shoppers in the zone
							zonesLast30s[IDToIndex[dataArray[i].value.zoneID]] += dataArray[i].value.count;
						}
					}

					var chart = $('#chartContainer').highcharts()
									
					for (var i = 0; i < zonesLast30s.length; i++) {
						// Compute the average number of shoppers per minute
						zonesLast30s[i] = zonesLast30s[i]/(3);
						chart.series[1].data[i].update(zonesLast30s[i]); 
					}
	
					});
				
			};  // end shopperData()	
			
			// Refresh the data and compute the average number of customer for the past 30s only on a 4s interval (+1-2s of computing time)
			setInterval(function() {
				setTimeout(update30sData, 0);
			}, 1000*4);
			
			// updateDayData should be used but is too ressource intensive and time consuming for a demo, as it has to analyse quite a lot of data.
			// Needs to be optimized for production purposes.
			//updateDayData();
			
			// Instead use this to set fixed values for each store, based on real data but pre-computed.
			$("#stores").change(function() {
				var chart = $('#chartContainer').highcharts();
				var fixedValues;
				if($("#stores option:selected").text() === 'GO-CO-001')
				  fixedValues = [4.3, 3.9, 4.5, 6, 3.2];
				else if($("#stores option:selected").text() === 'GO-CO-002')
				  fixedValues = [3.3, 3.7, 3.9, 1.1, 4.0];
				else if($("#stores option:selected").text() === 'GO-CO-003')
				  fixedValues = [3.9, 4.0, 4.2, 0.9, 4.0];
				else if($("#stores option:selected").text() === 'GO-CO-004')
				  fixedValues = [3.5, 3.5, 3.9, 1.3, 4.1];
		  		for (var i = 0; i < fixedValues.length; i++) {
					chart.series[0].data[i].update(fixedValues[i]); 
				}
				
				// Compute the value for the new store for the past 30s
				setTimeout(update30sData, 0);
			});
		});  // documentReady