#!/bin/bash
# Replace with your Cloudant URL that you can get in the credentials tab

url="https://9cdf2b01-2f08-4528-a114-c47f91c76097-bluemix:1216109559016044e3367opa021613d8ec0ba89f68fb644957d748a4964bc595@9cdf2b01-2f08-4528-a114-c47f91c76097-bluemix.cloudant.com"
for i in {1..22}; do
	curl -X POST -d @data${i}.json "$url/greatoutdoors/_bulk_docs" -H "Content-Type:application/json";
done;